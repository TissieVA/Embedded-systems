/**************************************************************************//**
 * @file
 * @brief Energy Modes example
 * @version 2.00
*******************************************************************************
 * @section License
 * <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 * DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Silicon Labs has no
 * obligation to support this Software. Silicon Labs is providing the
 * Software "AS IS", with no express or implied warranties of any kind,
 * including, but not limited to, any implied warranties of merchantability
 * or fitness for any particular purpose or warranties against infringement
 * of any proprietary rights of a third party.
 *
 * Silicon Labs will not be liable for any consequential, incidental, or
 * special damages, or any other relief, or for any claim by any third party,
 * arising from your use of this Software.
 *
 ******************************************************************************/

#include <stdio.h>

#include "em_device.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_pcnt.h"

#include "display.h"
#include "textdisplay.h"

/* Frequency of RTC (COMP0) pulses on PRS channel 2 */
#if defined (SLSTK3401A)
#define RTC_PULSE_FREQUENCY    (LS013B7DH03_POLARITY_INVERSION_FREQUENCY / 2)
#else
#define RTC_PULSE_FREQUENCY    LS013B7DH03_POLARITY_INVERSION_FREQUENCY
#endif

static volatile uint32_t seconds = 0;     /* seconds elapsed */

/**************************************************************************//**
 * @brief   Set up PCNT to generate an interrupt every second.
 *
 *****************************************************************************/
void PcntInit(void)
{
  PCNT_Init_TypeDef pcntInit = PCNT_INIT_DEFAULT;

  /* Enable PCNT clock */
  CMU_ClockEnable(cmuClock_PCNT0, true);

  /* Set up the PCNT to count RTC_PULSE_FREQUENCY pulses -> one second */
  pcntInit.mode = pcntModeOvsSingle;
  pcntInit.top = RTC_PULSE_FREQUENCY;
  pcntInit.s1CntDir = false;

  /* The PRS channel used depends on the configuration and to which pin
  the LCD inversion toggle is connected, so use the generic define here. */
  pcntInit.s0PRS = (PCNT_PRSSel_TypeDef)LCD_AUTO_TOGGLE_PRS_CH;

  PCNT_Init(PCNT0, &pcntInit);

  /* Select PRS as the input for the PCNT */
  PCNT_PRSInputEnable(PCNT0, pcntPRSInputS0, true);

  /* Enable PCNT interrupt every second */
  NVIC_EnableIRQ(PCNT0_IRQn);
  PCNT_IntEnable(PCNT0, PCNT_IF_OF);
}

/**************************************************************************//**
 * @brief   This interrupt is triggered at every second by the PCNT
 *
 *****************************************************************************/
void PCNT0_IRQHandler(void)
{
  PCNT_IntClear(PCNT0, PCNT_IF_OF);

  seconds++;

  return;
}

/**************************************************************************//**
 * @brief  Main function
 *****************************************************************************/
int main( void )
{
	/* Chip errata */
	CHIP_Init();

#if defined (SLSTK3401A)
	EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
	CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;

	/* Init DCDC regulator and HFXO with kit specific parameters */
	EMU_DCDCInit(&dcdcInit);
	CMU_HFXOInit(&hfxoInit);

	/* Select ULFRCO as clock source for LFA */
	CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_ULFRCO);
#endif

  /* Initialize display */
  DISPLAY_Init();

  /* Setup a config struct for TEXTDISPLAY */
  TEXTDISPLAY_Config_t conf;
  conf.displayDeviceNo = 0;
  conf.lfToCrLf = true;
  conf.scrollEnable = false;

  /* Create a TEXTDISPLAY device */
  TEXTDISPLAY_Handle_t  handle;
  TEXTDISPLAY_New(&conf, &handle);

  /* Set PCNT to generate an interrupt every second. */
  PcntInit();

  /* Turn on LFXO to be able to see the difference between EM2 and EM3. */
  CMU_OscillatorEnable(cmuOsc_LFXO, true, false );

  /* Wait in this loop at end of program */
  while(1)
  {
    /* Write to LCD */
	TEXTDISPLAY_WriteString(handle, "\r--EM2--");

    /* Wait for 5 seconds in EM2 */
	while (seconds < 5) EMU_EnterEM2(false);
	seconds = 0;

    /* Write to LCD */
	TEXTDISPLAY_WriteString(handle, "\r--EM1--");

    /* Wait for 5 seconds in EM1 */
	while (seconds < 5) EMU_EnterEM1();
	seconds = 0;
  }
}
