/******************************************************************************
 * @file
 * @brief Energy Modes example
 * @version 2.00
*******************************************************************************
 * @section License
 * <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
 *******************************************************************************
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 * DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Silicon Labs has no
 * obligation to support this Software. Silicon Labs is providing the
 * Software "AS IS", with no express or implied warranties of any kind,
 * including, but not limited to, any implied warranties of merchantability
 * or fitness for any particular purpose or warranties against infringement
 * of any proprietary rights of a third party.
 *
 * Silicon Labs will not be liable for any consequential, incidental, or
 * special damages, or any other relief, or for any claim by any third party,
 * arising from your use of this Software.
 *
 ******************************************************************************/

#include "em_chip.h"
#include "em_device.h"
#include "em_cmu.h"
#include "em_emu.h"
#if defined (SLSTK3401A)
#include "em_rtcc.h"
#else
#include "em_rtc.h"
#endif

#define LFRCO_FREQUENCY			32768
#define WAKEUP_INTERVAL_MS		5000
#define COUNT_BETWEEN_WAKEUP	((LFRCO_FREQUENCY * WAKEUP_INTERVAL_MS) / 1000)

#if defined (SLSTK3401A)
static void rtccSetup(void);
#else
static void rtcSetup(void);
#endif /* SLSTK3401A */

/******************************************************************************
 * @brief RTC/RTCC interrupt handlers.
 *****************************************************************************/
#if defined (SLSTK3401A)
void RTCC_IRQHandler(void)
{
  /* Clear interrupt source */
  RTCC_IntClear(RTCC_IF_CC1);
}
#else
void RTC_IRQHandler(void)
{ 
  /* Clear interrupt source */
  RTC_IntClear(RTC_IFC_COMP0);
}
#endif /* SLSTK3401A */

/******************************************************************************
 * @brief  Main function
 *
 *****************************************************************************/
int main(void)
{ 
  /* Start LFRCO and wait until it is stable */
  CMU_OscillatorEnable(cmuOsc_LFRCO, true, true);

  /* Enable clock to low energy modules */
  CMU_ClockEnable(cmuClock_CORELE, true);

#if defined (SLSTK3401A)
  rtccSetup();
#else
  rtcSetup();
#endif /* SLSTK3401A */
  
  /* Loop between EM2 and EM1 */
  while(1){
    /* Enter EM2 and wait for RTC interrupt */
    EMU_EnterEM2(false);
    
    /* Enter EM1 and wait for RTC interrupt */
    EMU_EnterEM1();
  }
}

#if defined(SLSTK3401A)
/**************************************************************************//**
 * @brief Enables LFECLK and selects clock source for RTCC
 *        Sets up the RTCC to generate an interrupt every second.
 *****************************************************************************/
void rtccSetup(void)
{
  RTCC_Init_TypeDef rtccInit = RTCC_INIT_DEFAULT;
  rtccInit.presc = rtccCntPresc_1;

  /* Select LFRCO as the low-frequency clock source */
  CMU_ClockSelectSet(cmuClock_LFE, cmuSelect_LFRCO);

  /* Enable RTCC clock */
  CMU_ClockEnable(cmuClock_RTCC, true);

  /* Initialize RTCC */
  rtccInit.enable   = false;  		/* Do not start RTC after initialization is complete. */
  rtccInit.debugRun = false;  		/* Halt RTC when debugging. */
  rtccInit.cntWrapOnCCV1 = true;	/* Wrap around on CCV1 match. */
  RTCC_Init(&rtccInit);

  /* Interrupt at given frequency. */
  RTCC_CCChConf_TypeDef ccchConf = RTCC_CH_INIT_COMPARE_DEFAULT;
  ccchConf.compMatchOutAction = rtccCompMatchOutActionToggle;
  RTCC_ChannelInit(1, &ccchConf);
  RTCC_ChannelCCVSet(1, COUNT_BETWEEN_WAKEUP - 1);

  /* Enable RTCC interrupt from CC1 */
  RTCC_IntEnable(RTCC_IEN_CC1);

  /* Enable RTC interrupt vector in NVIC */
  NVIC_EnableIRQ(RTCC_IRQn);

  /* Reset and start counter */
  RTCC->CNT = _RTCC_CNT_RESETVALUE;
  RTCC_Enable(true);
}
#else
/**************************************************************************//**
 * @brief Enables the RTC clock and sets it up to generate an interrupt
 *        every second.
 *****************************************************************************/
void rtcSetup(void)
{
  RTC_Init_TypeDef rtcInit = RTC_INIT_DEFAULT;

  /* Enable RTC clock */
  CMU_ClockEnable(cmuClock_RTC, true);

  /* Initialize RTC */
  rtcInit.enable   = false;  /* Do not start RTC after initialization is complete. */
  rtcInit.debugRun = false;  /* Halt RTC when debugging. */
  rtcInit.comp0Top = true;   /* Wrap around on COMP0 match. */

  RTC_Init(&rtcInit);

  /* Set RTC compare value */
  RTC_CompareSet(0, COUNT_BETWEEN_WAKEUP - 1);

  /* Enable RTC interrupt from COMP0 */
  RTC_IntEnable(RTC_IF_COMP0);

  /* Enable RTC interrupt vector in NVIC */
  NVIC_EnableIRQ(RTC_IRQn);

  /* Reset and start counter */
  RTC_CounterReset();
  RTC_Enable(true);
}
#endif /* SLSTK3401A */
